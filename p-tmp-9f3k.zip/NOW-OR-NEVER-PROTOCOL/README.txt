NOW OR NEVER — THE PROTOCOL
============================

You bought the system. Here's what's in the box:

1. The-Protocol.pdf
   The full 90-day system. Read "Read This First" tonight.
   Read Part III (the Reset Protocol) BEFORE you need it.

2. Wall-Chart-90-Days.pdf (+ 30 and 60 day versions)
   Print it. Tape it where you sleep. Cross off days by hand.

3. wallpapers/ (6 lock screens, 1080x1920)
   Set one now. Your phone should work for you, not against you.

UNLOCK PRO IN THE TRACKER
-------------------------
1. Open the tracker: https://stopchoosingnever.vercel.app
2. Menu (or "Already bought it?" link) -> Enter license key
3. Paste the license key from this receipt / your Gumroad email
4. Done. Custom rules, stats, wallpaper generator, printable chart.

Your license works on any device. Data stays on your device -
export a backup from the Menu if you switch phones.

Questions or a broken file? Reply to your Gumroad receipt email.

It's now or never. Stop choosing never.
